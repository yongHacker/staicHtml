
window.onload=function(){ 
    /*信息间歇滚动*/
    var timer;
    Scroll();
    $(".nav-news").hover(function(){
        clearInterval(timer);
    },Scroll).trigger('hover');

    function Scroll() {
        timer=setInterval(function(){
            var ul=$(".nav-news ul");
            var liHeight=ul.find("li").height();
            ul.animate({marginTop:'-'+liHeight+'px'}, 2000,function(){
                ul.find("li:first").appendTo(ul);
                ul.css({marginTop: '0'});
            });
        }, 3000);
    }
    /*图片轮播*/
    var liWidth=$("#pic li:first").width();
    var liNum=$("#pic li").length;
    var ulWidth=liWidth*liNum;
    $("#pic").css({
        width: ulWidth+'px'
    });
    var index=0;
    var adTimer;
    $(".play-picture").hover(function() {
        clearInterval(adTimer);
    }, function() {
        adTimer=setInterval(function(){
            $("#pic").animate({"marginLeft":-liWidth*index+'px'}, 3000);
            $("#pic li").removeClass('on').eq(index).addClass('on');;
            index++;
            if(index==liNum){
                index=0;
            }
        }, 4000);
    }).trigger('mouseleave');
    
    /*选项卡切换*/
    var $lis=$(".left-tab-head li");
    $(".mod").eq(index).show();
    $lis.mouseover(function(){
        $(this).addClass('select');
        $(this).siblings("li").removeClass('select');
        var index=$lis.index(this);
        $(".mod").eq(index).show().siblings().hide();
    });

    /*图片列表滑动展示*/
    var ulPicList=$("#picList-ul");
    var liPicWidth=$("#picList-ul li:first").width();
    var liPicNum=$("#picList-ul li").length;
    var ulPicListWidth=liPicWidth*liPicNum;
    var idx=0;
    var indx=0;
    var curMarginLeft;
     $("#picList-ul").css({
        width: ulPicListWidth+'px'
    });

     $("#leftButton").click(function(event) { 
        /*$("#picList-ul").css({
            marginLeft: curMarginLeft
        });*/
         $("#picList-ul").animate({"marginLeft":'-'+liPicWidth*idx+'px'}, 1000);
         idx++;
         if(idx==liPicNum){
            idx=0;
         }
         curMarginLeft=ulPicList.css('marginLeft');   
     });

      $("#rightButton").click(function(event) { 
    /*    $("#picList-ul").css({
            marginLeft: curMarginLeft
        });*/
          $("#picList-ul").animate({"marginLeft":liPicWidth*indx+'px'}, 1000);
          indx++;
          if(indx==liPicNum){
            indx=0;
         }
          curMarginLeft=ulPicList.css('marginLeft'); 
        
     });

}